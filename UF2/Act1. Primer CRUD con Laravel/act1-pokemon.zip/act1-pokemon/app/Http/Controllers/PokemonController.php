<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'tipo' => 'required',
            'size' => 'required',
            'peso' => ['required', 'min:0', 'numeric', 'decimal:1', 'max:9999']
        ]);

        Pokemon::create($validados);

        return to_route('home')
            ->with('status', 'Pokémon creado de forma satisfactoria!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Pokemon $pokemon)
    {
        return view('pokemon', [
            'pokes' => Pokemon::all()
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pokemon $pokemon)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pokemon $pokemon)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pokemon $pokemon)
    {
        //
    }
}
