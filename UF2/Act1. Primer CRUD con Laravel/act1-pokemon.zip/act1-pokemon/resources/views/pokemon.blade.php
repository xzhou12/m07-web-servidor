@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif
<title>Pokémons</title>

<h1>Añade pokémons a tu pokedex</h1>

<form method="POST">
    @csrf
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre">
    @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>
    <label for="tipo">Tipo:</label>
    <select name="tipo" id="tipo">
        <option value="fuego">Fuego</option>
        <option value="agua">Agua</option>
        <option value="planta">Planta</option>
        <option value="electrico">Electrico</option>
        <option value="volador">Volador</option>
        <option value="psiquico">Psiquico</option>
    </select>
    @error('tipo') <span class="error">{{ $message }}</span> @enderror<br><br>

    <label for="size">Tamaño:</label>
    <select name="size" id="size">
        <option value="small">Pequeño</option>
        <option value="medium">Mediano</option>
        <option value="grande">Grande</option>
    </select>
    @error('size') <span class="error">{{ $message }}</span> @enderror<br><br>

    <label for="peso">Peso:</label>
    <input type="text" name="peso" id="peso">
    @error('peso') <span class="error">{{ $message }}</span> @enderror<br><br>

    <input type="submit">
</form>

<style>
    .error {
        color: darkred;
    }
</style>
