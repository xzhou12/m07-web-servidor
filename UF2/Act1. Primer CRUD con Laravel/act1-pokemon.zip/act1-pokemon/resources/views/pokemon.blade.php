@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif
<title>Pokémons</title>

<div class="flex">
    <div>
        <h1>Añade pokémons a tu pokedex</h1>
        <form method="POST" action="{{ route('pokemon.store') }}">
            @csrf
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre">
            @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>
            <label for="tipo">Tipo:</label>
            <select name="tipo" id="tipo">
                <option value="fuego">Fuego</option>
                <option value="agua">Agua</option>
                <option value="planta">Planta</option>
                <option value="electrico">Electrico</option>
                <option value="volador">Volador</option>
                <option value="psiquico">Psiquico</option>
            </select>
            @error('tipo') <span class="error">{{ $message }}</span> @enderror<br><br>

            <label for="size">Tamaño:</label>
            <select name="size" id="size">
                <option value="pequeno">Pequeño</option>
                <option value="Mediano">Mediano</option>
                <option value="Grande">Grande</option>
            </select>
            @error('size') <span class="error">{{ $message }}</span> @enderror<br><br>

            <label for="peso">Peso:</label>
            <input type="text" name="peso" id="peso">
            @error('peso') <span class="error">{{ $message }}</span> @enderror<br><br>

            <input type="submit" value="Añadir pokémon">
        </form>
    </div>
    <div>
        <form method="GET" action="{{ route('pokemon.show') }}">
            <h1>Mostrar pokédex</h1>
            <input type="submit" value="Mostrar pokédex">
        </form>
        <br>
        <br>


        @if (isset($pokes))
            @if (count($pokes) > 0)
                <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                </tr>
            @foreach ($pokes as $poke)
                <tr>
                    <td>
                        {{ $poke->id }}
                    </td>
                    <td>
                        {{ $poke->nombre }}
                    </td>
                    <td>
                        {{ $poke->tipo }}
                    </td>
                    <td>
                        {{ $poke->size }}
                    </td>
                    <td>
                        {{ $poke->peso }}
                    </td>
                </tr>
            @endforeach
            </table>
            @else
                <h3>Sin datos para mostrar</h3>
            @endif
        @endif
    </div>
</div>


<style>
    .error {
        color: darkred;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }
</style>
