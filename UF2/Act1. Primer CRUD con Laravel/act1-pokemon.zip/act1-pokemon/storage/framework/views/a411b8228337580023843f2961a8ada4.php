<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>
<title>Pokémons</title>

<div class="flex">
    <div>
        <h1>Añade pokémons a tu pokedex</h1>
        <form method="POST" action="<?php echo e(route('pokemon.store')); ?>">
            <?php echo csrf_field(); ?>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>
            <label for="tipo">Tipo:</label>
            <select name="tipo" id="tipo">
                <option value="fuego">Fuego</option>
                <option value="agua">Agua</option>
                <option value="planta">Planta</option>
                <option value="electrico">Electrico</option>
                <option value="volador">Volador</option>
                <option value="psiquico">Psiquico</option>
            </select>
            <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for="size">Tamaño:</label>
            <select name="size" id="size">
                <option value="pequeno">Pequeño</option>
                <option value="Mediano">Mediano</option>
                <option value="Grande">Grande</option>
            </select>
            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for="peso">Peso:</label>
            <input type="text" name="peso" id="peso">
            <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <input type="submit" value="Añadir pokémon">
        </form>
    </div>
    <div>
        <form method="GET" action="<?php echo e(route('pokemon.show')); ?>">
            <h1>Mostrar pokédex</h1>
            <input type="submit" value="Mostrar pokédex">
        </form>
        <br>
        <br>


        <?php if(isset($pokes)): ?>
            <?php if(count($pokes) > 0): ?>
                <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                </tr>
            <?php $__currentLoopData = $pokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($poke->id); ?>

                    </td>
                    <td>
                        <?php echo e($poke->nombre); ?>

                    </td>
                    <td>
                        <?php echo e($poke->tipo); ?>

                    </td>
                    <td>
                        <?php echo e($poke->size); ?>

                    </td>
                    <td>
                        <?php echo e($poke->peso); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
                <h3>Sin datos para mostrar</h3>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>


<style>
    .error {
        color: darkred;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act1-pokemon/resources/views/pokemon.blade.php ENDPATH**/ ?>