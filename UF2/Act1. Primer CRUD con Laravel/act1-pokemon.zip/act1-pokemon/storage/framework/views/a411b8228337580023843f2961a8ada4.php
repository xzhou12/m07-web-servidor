<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>
<title>Pokémons</title>

<h1>Añade pokémons a tu pokedex</h1>

<form method="POST">
    <?php echo csrf_field(); ?>
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre">
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>
    <label for="tipo">Tipo:</label>
    <select name="tipo" id="tipo">
        <option value="fuego">Fuego</option>
        <option value="agua">Agua</option>
        <option value="planta">Planta</option>
        <option value="electrico">Electrico</option>
        <option value="volador">Volador</option>
        <option value="psiquico">Psiquico</option>
    </select>
    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for="size">Tamaño:</label>
    <select name="size" id="size">
        <option value="small">Pequeño</option>
        <option value="medium">Mediano</option>
        <option value="grande">Grande</option>
    </select>
    <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for="peso">Peso:</label>
    <input type="text" name="peso" id="peso">
    <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit">
</form>

<style>
    .error {
        color: darkred;
    }
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act1-pokemon/resources/views/pokemon.blade.php ENDPATH**/ ?>