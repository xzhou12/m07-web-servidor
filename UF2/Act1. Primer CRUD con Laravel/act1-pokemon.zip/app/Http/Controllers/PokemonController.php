<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'tipo' => 'required',
            'size' => ['required', 'in:pequeño,mediano,grande'],
            'peso' => ['required', 'min:0', 'numeric', 'decimal:1', 'max:9999']
        ], [
            'size.in' => 'El tamaño debe ser pequeño, mediano o grande.',
        ]);

        Pokemon::create($validados);

        return to_route('home')
            ->with('status', 'Pokémon creado de forma satisfactoria!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Pokemon $pokemon)
    {
        return view('pokemon', [
            'pokes' => Pokemon::all()
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($pokemon)
    {
        $pokemon = Pokemon::findOrFail($pokemon);
        return view('edit', [
           'poke' => $pokemon
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $pokemon)
    {
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'tipo' => 'required',
            'size' => ['required', 'in:pequeño,mediano,grande'],
            'peso' => ['required', 'min:0', 'numeric', 'decimal:1', 'max:9999']
        ], [
            'size.in' => 'El tamaño debe ser pequeño, mediano o grande.',
        ]);

        $pokemon = Pokemon::findOrFail($pokemon);
        $pokemon->update($validados);

        return to_route('home')
            ->with('status', $request->nombre . ' modificado de forma satisfactoria!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($pokemon)
    {
        $pokemon = Pokemon::findOrFail($pokemon);
        $pokemon->delete();

        return to_route('home')
            ->with('status', $pokemon->nombre . ' se ha eliminado de tu Pokédex de forma definitiva :(');
    }
}
