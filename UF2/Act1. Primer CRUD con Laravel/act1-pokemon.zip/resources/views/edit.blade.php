<h1>Edita el pokémon {{ $poke->nombre }}</h1>
<form method="POST" action="{{ route('pokemon.update', $poke) }}">
    @csrf @method('PUT')
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre" value="{{ old('nombre', $poke->nombre) }}">
    @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>
    <label for="tipo">Tipo:</label>
    <select name="tipo" id="tipo">
        <option value="fuego" {{ $poke->tipo === 'fuego' ? 'selected' : '' }}>Fuego</option>
        <option value="agua" {{ $poke->tipo === 'agua' ? 'selected' : '' }}>Agua</option>
        <option value="planta" {{ $poke->tipo === 'planta' ? 'selected' : '' }}>Planta</option>
        <option value="electrico" {{ $poke->tipo === 'electrico' ? 'selected' : '' }}>Electrico</option>
        <option value="volador" {{ $poke->tipo === 'volador' ? 'selected' : '' }}>Volador</option>
        <option value="psiquico" {{ $poke->tipo === 'psiquico' ? 'selected' : '' }}>Psiquico</option>
    </select>
    @error('tipo') <span class="error">{{ $message }}</span> @enderror<br><br>

    <label for="size">Tamaño:</label>
    <input type="text" name="size" id="size" value="{{ old('size', $poke->size) }}">
    @error('size') <span class="error">{{ $message }}</span> @enderror<br><br>

    <label for="peso">Peso:</label>
    <input type="text" name="peso" id="peso" value="{{ old('peso', $poke->peso) }}">
    @error('peso') <span class="error">{{ $message }}</span> @enderror<br><br>

    <input type="submit" value="Editar pokemon">
</form>
