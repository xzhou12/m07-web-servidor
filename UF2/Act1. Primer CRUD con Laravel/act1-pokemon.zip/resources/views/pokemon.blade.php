<!-- Si hay algun mensaje, saldrá aqui -->
@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif
<title>Pokémons</title>

<div class="flex">
    <div>
        <h1>Añade pokémons a tu pokedex</h1>
        <form method="POST" action="{{ route('pokemon.store') }}">
            @csrf <!-- Token csfr -->
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" value="{{ old('nombre') }}">
            <!-- Si hay algun error, saldrá aqui -->
            @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>
            <label for="tipo">Tipo:</label>
            <select name="tipo" id="tipo">
                <option value="fuego" {{ old('tipo') === 'fuego' ? 'selected' : '' }}>Fuego</option>
                <option value="agua" {{ old('tipo') === 'agua' ? 'selected' : '' }}>Agua</option>
                <option value="planta" {{ old('tipo') === 'planta' ? 'selected' : '' }}>Planta</option>
                <option value="electrico" {{ old('tipo') === 'electrico' ? 'selected' : '' }}>Electrico</option>
                <option value="volador" {{ old('tipo') === 'volador' ? 'selected' : '' }}>Volador</option>
                <option value="psiquico" {{ old('tipo') === 'psiquico' ? 'selected' : '' }}>Psiquico</option>
            </select>
            <!-- Si hay algun error, saldrá aqui -->
            @error('tipo') <span class="error">{{ $message }}</span> @enderror<br><br>

            <label for="size">Tamaño:</label>
            <input type="text" name="size" id="size" placeholder="tamaño en minusculas" value="{{ old('size') }}">
            <!-- Si hay algun error, saldrá aqui -->
            @error('size') <span class="error">{{ $message }}</span> @enderror<br><br>

            <label for="peso">Peso:</label>
            <input type="text" name="peso" id="peso" value="{{ old('peso') }}">
            <!-- Si hay algun error, saldrá aqui -->
            @error('peso') <span class="error">{{ $message }}</span> @enderror<br><br>

            <input type="submit" value="Añadir pokémon">
        </form>
    </div>
    <div>
        <form method="GET" action="{{ route('pokemon.show') }}">
            <h1>Mostrar pokédex</h1>
            <input type="submit" value="Mostrar pokédex">
        </form>
        <br>

        <!-- Si se ha pasado $pokes por parametro, entra la funcion -->
        @if (isset($pokes))
            <!-- Cuenta cuantos registros hay -->
            @if (count($pokes) > 0)
                <table>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Tipo</th>
                        <th>Tamaño</th>
                        <th>Peso</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>

                    <!-- foreach para recorrer cada registro de pokemons -->
                    @foreach ($pokes as $poke)
                        <tr>
                            <td>
                                {{ $poke->id }}
                            </td>
                            <td>
                                {{ $poke->nombre }}
                            </td>
                            <td>
                                {{ $poke->tipo }}
                            </td>
                            <td>
                                {{ $poke->size }}
                            </td>
                            <td>
                                {{ $poke->peso }}
                            </td>
                            <td>
                                <!-- Si se da a editar, se redirige a la ruta pokemon.edit -->
                                <a href="{{ route('pokemon.edit', $poke) }}">
                                    Editar
                                </a>
                            </td>
                            <td>
                                <!-- Si se quiere eliminar, se redirige a pokemon.destroy -->
                                <form method="POST" action="{{ route('pokemon.destroy', $poke) }}">
                                    @csrf @method('DELETE')
                                    <a href="route('pokemon.destroy', $poke)"
                                       onclick="event.preventDefault(); this.closest('form').submit();">
                                        Eliminar
                                    </a>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </table>
            @else
                <!-- Si no hay registros, muestra que no hay -->
                <h3>Sin datos para mostrar</h3>
            @endif
        @endif
    </div>
</div>


<style>
    .error {
        color: darkred;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }
</style>
