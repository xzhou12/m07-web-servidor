<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

/*
Route::get('/', function () {
    return view('welcome');
});

*/

Route::view('/', 'pokemon')->name('home');

Route::post('/create', [PokemonController::class, 'store'])
    ->name('pokemon.store');


Route::get('/show', [PokemonController::class, 'show'])
    ->name('pokemon.show');

Route::get('{poke}/edit', [PokemonController::class, 'edit'])
    ->name('pokemon.edit');

Route::put('/{poke}', [PokemonController::class, 'update'])
    ->name('pokemon.update');

Route::delete('/{poke}', [PokemonController::class, 'destroy'])
    ->name('pokemon.destroy');

/*
Route::get('/show', function (){
   return '<h1>hola</h1>';
})->name('pokemon.show');
*/
