<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>
<title>Pokémons</title>

<div class="flex">
    <div>
        <h1>Añade pokémons a tu pokedex</h1>
        <form method="POST" action="<?php echo e(route('pokemon.store')); ?>">
            <?php echo csrf_field(); ?>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>
            <label for="tipo">Tipo:</label>
            <select name="tipo" id="tipo">
                <option value="fuego" <?php echo e(old('tipo') === 'fuego' ? 'selected' : ''); ?>>Fuego</option>
                <option value="agua" <?php echo e(old('tipo') === 'agua' ? 'selected' : ''); ?>>Agua</option>
                <option value="planta" <?php echo e(old('tipo') === 'planta' ? 'selected' : ''); ?>>Planta</option>
                <option value="electrico" <?php echo e(old('tipo') === 'electrico' ? 'selected' : ''); ?>>Electrico</option>
                <option value="volador" <?php echo e(old('tipo') === 'volador' ? 'selected' : ''); ?>>Volador</option>
                <option value="psiquico" <?php echo e(old('tipo') === 'psiquico' ? 'selected' : ''); ?>>Psiquico</option>
            </select>
            <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for="size">Tamaño:</label>
            <input type="text" name="size" id="size" placeholder="tamaño en minusculas" value="<?php echo e(old('size')); ?>">
            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for="peso">Peso:</label>
            <input type="text" name="peso" id="peso" value="<?php echo e(old('peso')); ?>">
            <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <input type="submit" value="Añadir pokémon">
        </form>
    </div>
    <div>
        <form method="GET" action="<?php echo e(route('pokemon.show')); ?>">
            <h1>Mostrar pokédex</h1>
            <input type="submit" value="Mostrar pokédex">
        </form>
        <br>
        <?php if(isset($pokes)): ?>
            <?php if(count($pokes) > 0): ?>
                <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            <?php $__currentLoopData = $pokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($poke->id); ?>

                    </td>
                    <td>
                        <?php echo e($poke->nombre); ?>

                    </td>
                    <td>
                        <?php echo e($poke->tipo); ?>

                    </td>
                    <td>
                        <?php echo e($poke->size); ?>

                    </td>
                    <td>
                        <?php echo e($poke->peso); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('pokemon.edit', $poke)); ?>">
                            Editar
                        </a>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('pokemon.destroy', $poke)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <a href="route('pokemon.destroy', $poke)" onclick="event.preventDefault(); this.closest('form').submit();">
                                Eliminar
                            </a>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
                <h3>Sin datos para mostrar</h3>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>


<style>
    .error {
        color: darkred;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act1-pokemon/resources/views/pokemon.blade.php ENDPATH**/ ?>