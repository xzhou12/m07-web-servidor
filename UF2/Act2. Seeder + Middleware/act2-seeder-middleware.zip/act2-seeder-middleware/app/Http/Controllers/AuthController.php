<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // Retorna la pagina de login
    function login() {
        return view('login');
    }

    // Comprueba si las credenciales son las correctas
    function auth(Request $request) {

        // Valida los datos del formulario
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        // Añade que el campo admin solo pueda ser verdadero
        $credentials['admin'] = true;

        // Comprueba las credenciales con el modelo Auth
        if (Auth::attempt($credentials)) {

            // Si son correctas y es admin
            $request->session()->regenerate();

            // Devuelve la ruta admin
            return to_route('admin');
        } else {
            // Si no, devuelve login con un mensaje
            return to_route('login')
                ->with('status', 'Las credenciales son incorrectas o el usuario no es admin');

        }
    }

    // Elimina la sesión activa
    function logout() {
        Auth::logout();

        // Redirige a la home con mensaje de que ha cerrado sesión
        return to_route('home')
            ->with('status', 'Has cerrado sesión correctamente.');
    }
}
