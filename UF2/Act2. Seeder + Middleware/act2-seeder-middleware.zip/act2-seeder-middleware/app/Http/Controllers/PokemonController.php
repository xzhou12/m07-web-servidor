<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{
    /**
     * Guarda los pokemon en la base de datos
     */
    public function store(Request $request)
    {
        // Valida los datos
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'tipo' => 'required',
            'size' => ['required', 'in:pequeño,mediano,grande'],
            'peso' => ['required', 'min:0', 'numeric', 'decimal:1', 'max:9999']
        ], [
            'size.in' => 'El tamaño debe ser pequeño, mediano o grande.',
        ]);

        // Llama al modelo para crear el registro
        Pokemon::create($validados);

        // Vuelve a la home con un mensaje
        return to_route('admin')
            ->with('status', 'Pokémon creado de forma satisfactoria!');
    }

    /**
     * Retorna la vista pokemon para mostrar todos los pokemon
     */
    public function show(Pokemon $pokemon)
    {
        // Retorna la vista pokemon
        if (auth()->check()) {
            // Usuario autenticado, redirige a la vista para usuarios autenticados
            return view('pokemon', [
                'pokes' => Pokemon::all()
            ]);
        } else {
            // Usuario no autenticado, redirige a la vista para usuarios no autenticados
            return view('pokemon_user', [
                'pokes' => Pokemon::all()
            ]);
        }
    }

    /**
     * Muestra la vista para editar un pokemon
     */
    public function edit($pokemon)
    {
        // Busca al pokemon que se editara
        $pokemon = Pokemon::findOrFail($pokemon);

        // Se retorna la vista para editar
        return view('edit', [
           'poke' => $pokemon
        ]);
    }

    /**
     * Actualiza los datos del pokemon
     */
    public function update(Request $request, $pokemon)
    {
        // Valida los daots
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'tipo' => 'required',
            'size' => ['required', 'in:pequeño,mediano,grande'],
            'peso' => ['required', 'min:0', 'numeric', 'decimal:1', 'max:9999']
        ], [
            'size.in' => 'El tamaño debe ser pequeño, mediano o grande.',
        ]);

        // Busca el pokemon en la bbdd
        $pokemon = Pokemon::findOrFail($pokemon);
        // Actualiza la información
        $pokemon->update($validados);

        // Vuelve a la home con un mensaje
        return to_route('admin')
            ->with('status', $request->nombre . ' modificado de forma satisfactoria!');
    }

    /**
     * Destruye el registro del pokemon
     */
    public function destroy($pokemon)
    {
        // Llama al modelo para buscar al pokemon
        $pokemon = Pokemon::findOrFail($pokemon);
        // Y lo elimina
        $pokemon->delete();

        // Vuelve a la home con un mensaje
        return to_route('admin')
            ->with('status', $pokemon->nombre . ' se ha eliminado de tu Pokédex de forma definitiva :(');
    }
}
