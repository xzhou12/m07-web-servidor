<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pokemon', function (Blueprint $table) {
            $table->id();
            // Nombre, tipo y size de tipo string de longitud 100
            $table->string('nombre', 100);
            $table->string('tipo', 100);
            $table->string('size', 30);
            // Peso de tipo double con 4 digitos y 2 decimales
            $table->double('peso', 4, 2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pokemon');
    }
};
