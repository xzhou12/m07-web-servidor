<div>
    <form method="GET" action="{{ route('pokemon.show') }}">
        <h1>Mostrar pokédex</h1>
        <input type="submit" value="Mostrar pokédex">
    </form>
    <br>

    <!-- Si se ha pasado $pokes por parametro, entra la funcion -->
    @if (isset($pokes))
    <!-- Cuenta cuantos registros hay -->
    @if (count($pokes) > 0)
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Tamaño</th>
            <th>Peso</th>
        </tr>

        <!-- foreach para recorrer cada registro de pokemons -->
        @foreach ($pokes as $poke)
        <tr>
            <td>
                {{ $poke->id }}
            </td>
            <td>
                {{ $poke->nombre }}
            </td>
            <td>
                {{ $poke->tipo }}
            </td>
            <td>
                {{ $poke->size }}
            </td>
            <td>
                {{ $poke->peso }}
            </td>
        </tr>
        @endforeach
    </table>
    @else
    <!-- Si no hay registros, muestra que no hay -->
    <h3>Sin datos para mostrar</h3>
    @endif
    @endif


    <div class="log-in">
        <form method="GET" action="{{ route('login') }}">
            @csrf
            <input type="submit" value="Iniciar Sesión">
        </form>
    </div>
</div>
<style>
    .log-in {
        position: absolute;
        right: 50px;
        top: 50px;
    }
</style>
