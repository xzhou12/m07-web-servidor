<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;
use App\Http\Controllers\AuthController;
use App\Http\Middleware\Authenticate;

/**
 * {poke} es el ID del pokemon que queremos trabajar en el
 */

// Home
Route::view('/', 'pokemon_user')
    ->name('home');

// Para mostrarlo
Route::get('/show', [PokemonController::class, 'show'])
    ->name('pokemon.show');

// Mostrar pagina de login
Route::get('/login', [AuthController::class, 'login'])
    ->name('login');

// Verificar el registro
Route::post('/login/auth', [AuthController::class, 'auth'])
    ->name('auth');

// Middleware verificar si esta logueado
Route::middleware([Authenticate::class])->group(function () {
    Route::view('/admin', 'pokemon')->name('admin');

    // Para crear el pokemon
    Route::post('/create', [PokemonController::class, 'store'])
        ->name('pokemon.store');

    // Editar el pokemon
    Route::get('{poke}/edit', [PokemonController::class, 'edit'])
        ->name('pokemon.edit');

    // Actualizar datos del pokemon
    Route::put('/{poke}', [PokemonController::class, 'update'])
        ->name('pokemon.update');

    // Destruir el pokemon
    Route::delete('/{poke}', [PokemonController::class, 'destroy'])
        ->name('pokemon.destroy');

    // Logout
    Route::get('/logout', [AuthController::class, 'logout'])
        ->name('logout');
});

