<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('auth')); ?>">
    <?php echo csrf_field(); ?>
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email"><br>
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password"><br>
    <input type="submit" value="Iniciar sesión">
</form>
<?php /**PATH C:\xampp\htdocs\act2\resources\views/login.blade.php ENDPATH**/ ?>