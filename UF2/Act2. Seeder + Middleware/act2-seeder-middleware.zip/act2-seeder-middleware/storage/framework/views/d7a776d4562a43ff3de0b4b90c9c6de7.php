<div>
    <form method="GET" action="<?php echo e(route('pokemon.show')); ?>">
        <h1>Mostrar pokédex</h1>
        <input type="submit" value="Mostrar pokédex">
    </form>
    <br>

    <!-- Si se ha pasado $pokes por parametro, entra la funcion -->
    <?php if(isset($pokes)): ?>
    <!-- Cuenta cuantos registros hay -->
    <?php if(count($pokes) > 0): ?>
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Tamaño</th>
            <th>Peso</th>
        </tr>

        <!-- foreach para recorrer cada registro de pokemons -->
        <?php $__currentLoopData = $pokes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($poke->id); ?>

            </td>
            <td>
                <?php echo e($poke->nombre); ?>

            </td>
            <td>
                <?php echo e($poke->tipo); ?>

            </td>
            <td>
                <?php echo e($poke->size); ?>

            </td>
            <td>
                <?php echo e($poke->peso); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    <!-- Si no hay registros, muestra que no hay -->
    <h3>Sin datos para mostrar</h3>
    <?php endif; ?>
    <?php endif; ?>


    <div class="log-in">
        <form method="GET" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <input type="submit" value="Iniciar Sesión">
        </form>
    </div>
</div>
<style>
    .log-in {
        position: absolute;
        right: 50px;
        top: 50px;
    }
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act2/resources/views/pokemon_user.blade.php ENDPATH**/ ?>