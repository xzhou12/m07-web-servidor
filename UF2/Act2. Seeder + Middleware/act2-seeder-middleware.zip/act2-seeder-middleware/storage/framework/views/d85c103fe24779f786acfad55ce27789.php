<h1>Edita el pokémon <?php echo e($poke->nombre); ?></h1>
<form method="POST" action="<?php echo e(route('pokemon.update', $poke)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <!-- Como en HTML no existe el methodo PUT, ni PATCH, ni DETELE
    se debe definir en el formulario -->
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre" value="<?php echo e(old('nombre', $poke->nombre)); ?>">
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>
    <label for="tipo">Tipo:</label>
    <select name="tipo" id="tipo">
        <option value="fuego" <?php echo e($poke->tipo === 'fuego' ? 'selected' : ''); ?>>Fuego</option>
        <option value="agua" <?php echo e($poke->tipo === 'agua' ? 'selected' : ''); ?>>Agua</option>
        <option value="planta" <?php echo e($poke->tipo === 'planta' ? 'selected' : ''); ?>>Planta</option>
        <option value="electrico" <?php echo e($poke->tipo === 'electrico' ? 'selected' : ''); ?>>Electrico</option>
        <option value="volador" <?php echo e($poke->tipo === 'volador' ? 'selected' : ''); ?>>Volador</option>
        <option value="psiquico" <?php echo e($poke->tipo === 'psiquico' ? 'selected' : ''); ?>>Psiquico</option>
    </select>
    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for="size">Tamaño:</label>
    <input type="text" name="size" id="size" value="<?php echo e(old('size', $poke->size)); ?>">
    <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for="peso">Peso:</label>
    <input type="text" name="peso" id="peso" value="<?php echo e(old('peso', $poke->peso)); ?>">
    <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit" value="Editar pokemon">
</form>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act1/resources/views/edit.blade.php ENDPATH**/ ?>