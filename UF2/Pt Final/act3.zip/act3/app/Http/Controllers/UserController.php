<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function store(Request $request) {
        
        $validados = $request->validate([
            'nick' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'unique:users'],
            'nombre' => ['required', 'min:3', 'max:100'],
            'apellidos' => ['required', 'min:3', 'max:100'],
            'dni' => ['required', 'min:8', 'max:9', 'unique:users'],
            'nombre' => ['required', 'min:3', 'max:100'],
            'password' => ['required', 'min:6', 'confirmed'],
            'fecha_nacimiento' => ['required', 'date'],
            'rol' => ['required', 'in:user,admin'],
        ]);

        User::create($validados);

        return to_route('home')
            ->with('status', 'Usuario creado! Accede a ella para empezar a comprar');

    }

    public function login(Request $request) {
        
        $validados = $request->validate([
            'dni' => ['required', 'exists:users'],
            'password' => ['required']
        ]);

        // Comprueba las credenciales con el modelo Auth
        if (Auth::attempt($validados)) {

            // Si son correctas
            $request->session()->regenerate();

            // Devuelve la ruta
            return to_route('home');
        } else {
            // Si no, devuelve login con un mensaje
            return to_route('login')
                ->with('status', 'Las credenciales son incorrectas');
        }
        
    }

    // Elimina la sesión activa
    function logout() {
        Auth::logout();

        // Redirige a la home con mensaje de que ha cerrado sesión
        return to_route('home')
            ->with('status', 'Has cerrado sesión correctamente.');
    }
}
