@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif


<h1>Accede a tu cuenta</h1>
<form method="POST" action="{{ route('user.login') }}">
    @csrf <!-- Token csfr -->
    <label for="dni">DNI:</label>
    <input type="text" name="dni" id="dni" value="{{ old('dni') }}"><br>
    @error('dni') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for="password">Contraseña:</label>
    <input type="password" name="password" id="password"><br>
    @error('password') <span class="error">{{ $message }}</span>@enderror<br><br>

    <input type="submit" value="Acceder">

</form>