@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif

<a href="{{ route('login') }}">Login</a>
<a href="{{ route('register') }}">Register</a>