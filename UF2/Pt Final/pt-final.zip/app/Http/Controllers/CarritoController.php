<?php

namespace App\Http\Controllers;

use App\Models\Carrito;
use App\Models\Producto;
use Illuminate\Http\Request;

class CarritoController extends Controller
{

    /**
     * Guarda productos en el carrito
     */
    public function store(Request $request, Producto $producto)
    {

        // Comprueba que los datos sean correctos y no sea mayor al stock disponible
        $request->validate([
            'cantidad' => ['required', 'numeric', 'max:' . $producto->unidades, 'min:1'],
        ]);

        // Hace el insert
        Carrito::create([
            'producto' => $producto->id,
            'cantidad' => $request->cantidad,
            'precio_producto' => $producto->precio_unitario,
            'total' => ($request->cantidad * $producto->precio_unitario),
        ]);

        // Hace un update del stock del producto
        $producto->update([
            'unidades' => ($producto->unidades - $request->cantidad)
        ]);

        // Devuelve a la ruta con el mensaje
        return to_route('user.home')
            ->with('status', 'Producto añadido al carrito!');

    }

    /**
     * Hace un select de todos los datos de la tabla
     * y los envia a la vista
     */
    public function show()
    {
        return view('user', [
            'carritos' => Carrito::all()
        ]);
    }


    /**
     * Elimina el producto del carrito
     */
    public function destroy(Carrito $carrito)
    {
        // Elimina el producto del carrito
        $carrito->delete();

        // Busca el id del producto
        $producto = Producto::findOrFail($carrito->producto);

        // Y le suma el stock
        $producto->update([
            'unidades' => ($producto->unidades + $carrito->cantidad)
        ]);

        // Devuelve a la ruta con un mensaje
        return to_route('user.home')
            ->with('status', 'Producto eliminado del carrito correctamente!');
    }
}
