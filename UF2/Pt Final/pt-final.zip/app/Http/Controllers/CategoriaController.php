<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;

class CategoriaController extends Controller
{

    /**
     * Guarda la cateogoria en la base de datos
     */
    public function store(Request $request)
    {
        // Verifica que los datos sean correctos y que el nombre sea unico
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100', 'unique:categorias'],
            'descripcion' => ['required', 'max:255'],
        ]);

        // Crea la cateogria con los datos validados
        Categoria::create($validados);

        // Devuelve la ruta con un mensaje de categoria creada
        return to_route('admin.home')
            ->with('status', 'Categoria creada!');
    }

    /**
     * Hace un select de todos los datos de la tabla
     * y los envia a la vista del administrador
     */
    public function show()
    {
        return view('admin', [
            'categories' => Categoria::all()
        ]);
    }

    /**
     * Hace un select de todos los datos de la tabla
     * y los envia a la vista de usuario
     */
    public function showUser()
    {
        return view('user', [
            'categorias' => Categoria::all()
        ]);
    }

    /**
     * Muestra el formulario para editar la info
     */
    public function edit(Categoria $categoria)
    {
        return view('category_edit', [
            'category' => $categoria
        ]);
    }

    /**
     * Actualiza los datos de la categoria
     */
    public function update(Request $request, Categoria $categoria)
    {
        // Valida los datos
        $validados = $request->validate([
            // Valida que el nombre de la categoria sea unico menos con su registro
            'nombre' => ['required', 'min:3', 'max:100', 'unique:categorias,nombre,' . $categoria->id],
            'descripcion' => ['required', 'max:255'],
        ]);

        // Actualiza los datos con los datos validados
        $categoria->update($validados);

        // Devuelve a la home con un mensaje
        return to_route('admin.home')
            ->with('status', 'Categoria actualizada exitosamente!');
    }

    /**
     * Elimina la categoria de la base de datos
     */
    public function destroy(Categoria $categoria)
    {
        // Elimina el registro
        $categoria->delete();

        // Vuelve a la home con un mensaje
        return to_route('admin.home')
            ->with('status', 'La categoria ' . $categoria->nombre . ' se ha eliminado de forma satisfactoria!');
    }
}
