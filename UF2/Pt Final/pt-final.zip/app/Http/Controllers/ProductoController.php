<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;

class ProductoController extends Controller
{

    /**
     * Guarda el producto en la base de datos
     */
    public function store(Request $request)
    {
        // Valida los datos recibidos
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'descripcion' => ['required', 'max:255'],
            'unidades' => ['required', 'min:0', 'max_digits:11'],
            'precio_unitario' => ['required', 'numeric', 'min:0', 'max:9999999999'],
            'categoria' => ['required', 'exists:categorias,id'],
        ]);

        // Crea el producto
        Producto::create($validados);

        // Vuelve a la home del administrador y muestra un mensaje
        return to_route('admin.home')
            ->with('status', 'Producto creado!');
    }

    /**
     * Hace un select de todos los datos de la tabla
     * y los envia a la vista del administrador
     */
    public function show()
    {
        return view('admin', [
            'productos' => Producto::all()
        ]);
    }

    /**
     * Hace un select de todos los datos de la tabla
     * y los envia a la vista del usuario
     */
    public function showDefault()
    {
        return view('user', [
            'productos' => Producto::with('categoria')->get()
        ]);
    }

    /**
     * Hace un select de todos los datos de la tabla
     * ordenandolos por precio
     * y los envia a la vista del usuario
     */
    public function showSortPrice()
    {
        return view('user', [
            'productos' => Producto::orderBy('precio_unitario')->get()
        ]);
    }

    /**
     * Hace un select de todos los datos de la tabla
     * filtrando por cateogoria
     * y los envia a la vista
     */
    public function showSortCategory(Request $request)
    {
        // Valida que la categoria exista
        $request->validate([
            'categoria' => ['required', 'exists:categorias,id'],
        ]);

        return view('user', [
            'productos' => Producto::where('categoria', $request->categoria)->get()
        ]);
    }

    /**
     * Muestra el formulario para editar los productos
     */
    public function edit(Producto $producto)
    {

        return view('product_edit', [
            'product' => $producto
        ]);
    }

    /**
     * Actualiza los datos del producto
     */
    public function update(Request $request, Producto $producto)
    {
        // Antes valida toda la información
        $validados = $request->validate([
            'nombre' => ['required', 'min:3', 'max:100'],
            'descripcion' => ['required', 'max:255'],
            'unidades' => ['required', 'min:0'],
            'precio_unitario' => ['required', 'min:0'],
            'categoria' => ['required', 'exists:categorias,id'],
        ]);

        // Actualiza los productos
        $producto->update($validados);

        // Y devuelve la vista con un mensaje
        return to_route('admin.home')
            ->with('status', 'Producto actualizado correctamente!');
    }

    /**
     * Elimina el producto de la base de datos
     */
    public function destroy(Producto $producto)
    {
        // Elimina el producto
        $producto->delete();
        // Vuelve a la home con un mensaje
        return to_route('admin.home')
            ->with('status', 'El producto ' . $producto->nombre . ' se ha eliminado de forma satisfactoria!');
    }
}
