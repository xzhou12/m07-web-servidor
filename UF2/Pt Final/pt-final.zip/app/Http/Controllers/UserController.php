<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{

    /**
     * ADMIN
     * Guarda los datos del usuario en la base de datos
     */
    public function store(Request $request) {

        $validados = $request->validate([
            'nick' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'unique:users', 'max:255'],
            'nombre' => ['required', 'min:3', 'max:100'],
            'apellidos' => ['required', 'min:3', 'max:100'],
            'dni' => ['required', 'min:8', 'max:9', 'unique:users'],
            'password' => ['required', 'min:6', 'confirmed'],
            'fecha_nacimiento' => ['required', 'date'],
            'rol' => ['required', 'in:user,admin'],
        ]);

        User::create($validados);

        return to_route('admin.home')
            ->with('status', 'Usuario creado!');

    }

    /**
     * USUARIO
     * Registra los datos de un nuevo usuario en la base de datos
     */
    public function register(Request $request) {

        $validados = $request->validate([
            'nick' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'unique:users', 'max:255'],
            'nombre' => ['required', 'min:3', 'max:100'],
            'apellidos' => ['required', 'min:3', 'max:100'],
            'dni' => ['required', 'min:8', 'max:9', 'unique:users'],
            'password' => ['required', 'min:6', 'confirmed'],
            'fecha_nacimiento' => ['required', 'date'],
        ]);

        User::create($validados);

        return to_route('admin.home')
            ->with('status', 'Usuario creado! Accede a ella para empezar a comprar');

    }

    /**
     * Comprueba los datos del usuario para loguearse
     */
    public function login(Request $request) {

        $validados = $request->validate([
            'dni' => ['required', 'exists:users'],
            'password' => ['required']
        ]);

        // Comprueba las credenciales con el modelo Auth
        if (Auth::attempt($validados)) {

            // Si son correctas
            $request->session()->regenerate();


            // Si es admin, lo redirigimos a admin.home
            if (Auth::user()->rol == 'admin') {
                // Devuelve la ruta
                return to_route('admin.home')
                    ->with('status', 'Bienvenido admin ' . $request->user()->nick);

            } else {

                return to_route('user.home')
                    ->with('status', 'Bienvenido ' . $request->user()->nick);
            }
        } else {
            // Si no, devuelve login con un mensaje
            return to_route('login')
                ->with('status', 'Las credenciales son incorrectas');
        }

    }

    /**
     * Cierra sesión del usuario
     */
    function logout() {
        Auth::logout();

        // Redirige a la home con mensaje de que ha cerrado sesión
        return to_route('home')
            ->with('status', 'Has cerrado sesión correctamente.');
    }

    /**
     * ADMIN
     * Muestra todos los usuarios
     */
    function show() {
        return view('admin', [
            'users' => User::all()
        ]);
    }

    /**
     * USUARIO
     * Muestra el perfil del usuario para editar
     */
    function profile(User $user) {

        return view('user_profile', [
            'user' => $user
        ]);

    }

    /**
     * ADMIN
     * Muestra la vista para editar el usuario
     */
    function edit(User $user) {

        return view('user_edit', [
            'user' => $user
        ]);
    }

    /**
     * ADMIN
     * Actualiza los datos del usuario
     */
    function update(Request $request, User $user) {

        $validados = $request->validate([
            'nick' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'max:255', 'unique:users,email,' . $user->id],
            'nombre' => ['required', 'min:3', 'max:100'],
            'apellidos' => ['required', 'min:3', 'max:100'],
            'dni' => ['required', 'min:8', 'max:9', 'unique:users,dni,' . $user->id],
            'fecha_nacimiento' => ['required', 'date'],
            'rol' => ['required', 'in:user,admin'],
        ]);

        $user->update($validados);

        return to_route('admin.home')
            ->with('status', $request->nombre . ' modificado de forma satisfactoria!');
    }

    /**
     * USUARIO
     * Actualiza los datos del usuario
     */
    function userUpdate(Request $request, User $user) {

        $validados = $request->validate([
            'nick' => ['required', 'min:3', 'max:100'],
            'email' => ['required', 'max:255', 'unique:users,email,' . $user->id],
        ]);

        $user->update($validados);

        return to_route('user.home')
            ->with('status', 'Tus datos se han modificado de forma satisfactoria!');

    }

    /**
     * ADMIN
     * Elimina el usuario
     */
    function destroy(User $user) {

        // Y lo elimina
        $user->delete();

        // Vuelve a la home con un mensaje
        return to_route('admin.home')
            ->with('status', $user->nombre . ' se ha eliminado de forma satisfactoria!');
    }
}
