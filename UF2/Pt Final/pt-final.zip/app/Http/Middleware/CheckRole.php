<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, $role)
    {
        $user = Auth::user();

        // Verificar si el usuario está autenticado y tiene el rol correcto
        if (Auth::check() && $user->rol == $role) {
            return $next($request);
        } else {
            if ($user->rol == 'admin') {
                // Redirigir al usuario a otra pagina
                return to_route('admin.home')
                    ->with('status', 'Acceso denegado!');
            } else {
                // Redirigir al usuario a otra pagina
                return to_route('user.home')
                    ->with('status', 'Acceso denegado!');
            }
        }

    }
}
