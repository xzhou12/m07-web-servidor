<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Carrito extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Selecciona toda la tabla productos en formato array
        $producto = DB::table('productos')->get()->toArray();

        // Repite el loop 4 veces
        for ($i = 0; $i <= 3; $i++) {
            // Selecciona un producto aleatorio
            $prod = $producto[array_rand($producto)];
            // Y un numero entre 1 y 999
            $cantidad = mt_rand(1,999);

            DB::table('carritos')->insert([
                'id' => 0,
                // Inserta el id del producto
                'producto' => $prod->id,
                // Inserta la cantidad
                'cantidad' => $cantidad,
                // Inserta el precio_unitario
                'precio_producto' => $prod->precio_unitario,
                // Hace el calculo de la (cantidad * precio)
                'total' => ($cantidad * $prod->precio_unitario),
            ]);
        }

    }
}
