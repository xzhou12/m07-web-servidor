<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Categorias extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $opcion = ['fruta', 'verdura'];

        for ($i = 0; $i <= 3; $i++) {
            DB::table('categorias')->insert([
                'id' => 0,
                'nombre' => $opcion[array_rand($opcion)],
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            ]);
        }


    }
}
