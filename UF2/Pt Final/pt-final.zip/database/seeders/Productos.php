<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Productos extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $opcion = ['manzana', 'pera', 'plátano', 'uva', 'sandía', 'fresa', 'naranja', 'kiwi',
            'piña', 'mango', 'ciruela', 'papaya', 'cereza', 'melocotón', 'limón', 'zanahoria',
            'brócoli', 'espinaca', 'pepino', 'calabaza'];

        $opcion2 = ['roja', 'verde', 'amarillo', 'azul', 'naranja', 'rosa', 'gris',' blanco'];

        $categorias = DB::table('categorias')->pluck('id')->toArray();

        for ($i = 0; $i <= 20; $i++) {
            DB::table('productos')->insert([
                'id' => 0,
                'nombre' => $opcion[array_rand($opcion)] . ' ' . $opcion2[array_rand($opcion2)],
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
                'unidades' => mt_rand(1,99999),
                'precio_unitario' => mt_rand(1 * 10, 999 * 10) / 10,
                'categoria' => $categorias[array_rand($categorias)],
            ]);
        }
    }
}
