<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Productos extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        // Array de primeras opciones
        $opcion = ['manzana', 'pera', 'plátano', 'uva', 'sandía', 'fresa', 'naranja', 'kiwi',
            'piña', 'mango', 'ciruela', 'papaya', 'cereza', 'melocotón', 'limón', 'zanahoria',
            'brócoli', 'espinaca', 'pepino', 'calabaza'];

        // Array de segundas opciones
        $opcion2 = ['roja', 'verde', 'amarillo', 'azul', 'naranja', 'rosa', 'gris',' blanco'];

        // Selecciona todos los id existentes en la tabla categorias
        $categorias = DB::table('categorias')->pluck('id')->toArray();

        // Repite el loop 21 veces
        for ($i = 0; $i <= 20; $i++) {
            DB::table('productos')->insert([
                'id' => 0,
                // Selecciona una combinación aleatoria
                'nombre' => $opcion[array_rand($opcion)] . ' ' . $opcion2[array_rand($opcion2)],
                'descripcion' => 'Lorem ipsum',
                // Genera un numbero aleatorio
                'unidades' => mt_rand(1,99999),
                // Crea un precio aleatorio entre 1 y 999,99
                'precio_unitario' => mt_rand(1 * 10, 999 * 10) / 10,
                // Selecciona una cateoria aleatoria
                'categoria' => $categorias[array_rand($categorias)],
            ]);
        }
    }
}
