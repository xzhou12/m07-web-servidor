<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Users extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            'id' => 0,
            'nick' => 'admin',
            'email' => 'admin@admin.com',
            'nombre' => 'admin',
            'apellidos' => 'admin',
            'dni' => 'admin',
            'fecha_nacimiento' => '1-1-1',
            'password' => Hash::make('admin'),
            'rol' => 'admin',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'nick' => 'user',
            'email' => 'user@ping.com',
            'nombre' => 'user',
            'apellidos' => 'user',
            'dni' => 'user',
            'fecha_nacimiento' => '1-1-1',
            'password' => Hash::make('1'),
            'rol' => 'user',
        ]);
    }
}
