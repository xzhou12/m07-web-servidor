@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif


<div class="user-settings">
    <a href="#" class="logout">Cerrar sesión</a>

    <a href="{{ route('user.logout') }}" class="confirm-logout show">Confirmar cerrar sessión</a>
</div>

<h1>Usuarios!</h1>
<div class="flex usuarios">
    <div class="row">
        <h2>Crea un usuario:</h2>
        <form method="POST" action="{{ route('admin.add-user') }}">
            @csrf <!-- Token csfr -->
            <label for='nick'>Nick:</label>
            <input type='text' id='nick' name='nick' value="{{ old('nick') }}"><br>
            @error('nick') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='email'>Email:</label>
            <input type='email' id='email' name='email' value="{{ old('email') }}"><br>
            @error('email') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="{{ old('nombre') }}"><br>
            @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='apellidos'>Apellidos:</label>
            <input type='text' id='apellidos' name='apellidos' value="{{ old('apellidos') }}"><br>
            @error('apellidos') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='password'>Contraseña:</label>
            <input type='password' id='password' name='password'><br>
            @error('password') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='password_confirmation'>Confirmar contraseña:</label>
            <input type='password' id='password_confirmation' name='password_confirmation'><br>
            @error('password_confirmation') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='dni'>DNI:</label>
            <input type='text' id='dni' name='dni' value="{{ old('dni') }}"><br>
            @error('dni') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='fecha_nacimiento'>Fecha de Nacimiento:</label>
            <input type='date' id='fecha_nacimiento' name='fecha_nacimiento' value="{{ old('fecha_nacimiento') }}"><br>
            @error('fecha_nacimiento') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='rol'>Rol:</label>
            <select id='rol' name='rol'>
                <option value='user' {{ old('rol') === 'user' ? 'selected' : '' }}>Usuario</option>
                <option value='admin' {{ old('rol') === 'admin' ? 'selected' : '' }}>Administrador</option>
            </select><br>
            @error('rol') <span class="error">{{ $message }}</span>@enderror<br><br>

            <input type="submit" value="Crear cuenta">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos los usuarios</h2>
        <form method="GET" action="{{ route('admin.get-user') }}">
            @csrf <!-- Token csfr -->
            <input type="submit" value="Mostrar usuarios">
        </form>
        <br>
        <br>

        @if (isset($users))
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nick</th>
                    <th>Email</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>DNI</th>
                    <th>Fecha nacimiento</th>
                    <th>Rol</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de usuario -->
                @foreach ($users as $user)
                <tr>
                    <td>
                        {{ $user->id }}
                    </td>
                    <td>
                        {{ $user->nick }}
                    </td>
                    <td>
                        {{ $user->email }}
                    </td>
                    <td>
                        {{ $user->nombre }}
                    </td>
                    <td>
                        {{ $user->apellidos }}
                    </td>
                    <td>
                        {{ $user->dni }}
                    </td>
                    <td>
                        {{ $user->fecha_nacimiento }}
                    </td>
                    <td>
                        {{ $user->rol }}
                    </td>

                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-user -->
                        <a href="{{ route('admin.edit-user', $user) }}">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a  admin.destroy-user-->
                        <form method="POST" action="{{ route('admin.destroy-user', $user) }}">
                            @csrf @method('DELETE')
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                </tr>
                @endforeach
            </table>
        @endif
    </div>
</div>

<br>
<br>
<h1>Categorias!</h1>
<div class="flex categoria">
    <div class="row">
        <h2>Crea una categoria:</h2>
        <form method="POST" action="{{ route('admin.add-category') }}">
            @csrf <!-- Token csfr -->
            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="{{ old('nombre') }}"><br>
            @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='descripcion'>Descripción:</label>
            <input type='text' id='descripcion' name='descripcion' value="{{ old('descripcion') }}"><br>
            @error('descripcion') <span class="error">{{ $message }}</span>@enderror<br><br>

            <input type="submit" value="Crear categoria">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos las categorias</h2>
        <form method="GET" action="{{ route('admin.get-category') }}">
            @csrf <!-- Token csfr -->
            <input type="submit" value="Mostrar categorias">
        </form>
        <br>
        <br>

        @if (isset($categories))
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de una categoria -->
                @foreach ($categories as $category)
                <tr>
                    <td>
                        {{ $category->id }}
                    </td>
                    <td>
                        {{ $category->nombre }}
                    </td>
                    <td>
                        {{ $category->descripcion }}
                    </td>
                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-category -->
                        <a href="{{ route('admin.edit-category', $category) }}">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a admin.destroy-cateogry -->
                        <form method="POST" action="{{ route('admin.destroy-category', $category) }}">
                            @csrf @method('DELETE')
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                    </tr>
                @endforeach
            </table>
        @endif
    </div>
</div>

<br>
<br>
<h1>Productos!</h1>
<div class="flex productos">
    <div class="row">
        <h2>Crea un producto:</h2>
        <form method="POST" action="{{ route('admin.add-product') }}">
            @csrf <!-- Token csfr -->
            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="{{ old('nombre') }}"><br>
            @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='descripcion'>Descripción:</label>
            <input type='text' id='descripcion' name='descripcion' value="{{ old('descripcion') }}"><br>
            @error('descripcion') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='unidades'>Unidades:</label>
            <input type='number' id='unidades' name='unidades' value="{{ old('unidades') }}"><br>
            @error('unidades') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='precio_unitario'>Precio unitario:</label>
            <input type='number' id='precio_unitario' name='precio_unitario' step=".01" value="{{ old('precio_unitario') }}"><br>
            @error('precio_unitario') <span class="error">{{ $message }}</span>@enderror<br><br>

            <label for='categoria'>Categoria:</label>
            <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="{{ old('categoria') }}"><br>
            @error('categoria') <span class="error">{{ $message }}</span>@enderror<br><br>

            <input type="submit" value="Crear producto">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos los productos</h2>
        <form method="GET" action="{{ route('admin.get-products') }}">
            @csrf <!-- Token csfr -->
            <input type="submit" value="Mostrar productos">
        </form>

        @if (isset($productos))
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Unidades</th>
                    <th>Precio unitario</th>
                    <th>Categoria</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de una categoria -->
                @foreach ($productos as $product)
                <tr>
                    <td>
                        {{ $product->id }}
                    </td>
                    <td>
                        {{ $product->nombre }}
                    </td>
                    <td>
                        {{ $product->descripcion }}
                    </td>
                    <td>
                        {{ $product->unidades }}
                    </td>
                    <td>
                        {{ $product->precio_unitario }} €
                    </td>
                    <td>
                        {{ $product->categoria }}
                    </td>
                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-product -->
                        <a href="{{ route('admin.edit-product', $product) }}">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a admin.destroy-product -->
                        <form method="POST" action="{{ route('admin.destroy-product', $product) }}">
                            @csrf @method('DELETE')
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                    </tr>
                @endforeach
            </table>
        @endif
    </div>
</div>

<style>
    .log-out {
        position: absolute;
        right: 10vh;
        top: 5vh;
    }

    .error {
        color: red;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 10vh;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }

    .user-settings {
        position: absolute;
        right: 10vh;
        top: 5vh;
        display: flex;
        flex-flow: column;
        gap: 30px;
    }

    .show {
        display: none;
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
            let logout = document.querySelector('.logout');

            if(logout) {
                logout.addEventListener('click', function(event) {
                    event.preventDefault();
                    let confirm = document.querySelector('.confirm-logout');

                    if (confirm.classList.contains('show')) {
                        confirm.classList.remove('show');
                    } else {
                        confirm.classList.add('show');
                    }
                });
            }
        });
</script>