<form method="POST" action="{{ route('admin.update-category', $category) }}">
    @csrf @method('PUT')
    <!-- Token csfr -->
    <label for='nombre'>Nombre:</label>
    <input type='text' id='nombre' name='nombre' value="{{ old('nombre', $category->nombre) }}"><br>
    @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='descripcion'>Descripción:</label>
    <input type='text' id='descripcion' name='descripcion' value="{{ old('descripcion', $category->descripcion) }}"><br>
    @error('descripcion') <span class="error">{{ $message }}</span>@enderror<br><br>

    <input type="submit" value="Editar categoria">

</form>
<style>
    .error {
        color: red;
    }
</style>