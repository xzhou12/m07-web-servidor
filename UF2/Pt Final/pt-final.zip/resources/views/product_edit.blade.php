<form method="POST" action="{{ route('admin.update-product', $product) }}">
    @csrf @method('PUT')
    <label for='nombre'>Nombre:</label>
    <input type='text' id='nombre' name='nombre' value="{{ old('nombre', $product->nombre ) }}"><br>
    @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='descripcion'>Descripción:</label>
    <input type='text' id='descripcion' name='descripcion' value="{{ old('descripcion', $product->descripcion ) }}"><br>
    @error('descripcion') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='unidades'>Unidades:</label>
    <input type='number' id='unidades' name='unidades' value="{{ old('unidades', $product->unidades ) }}"><br>
    @error('unidades') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='precio_unitario'>Precio unitario:</label>
    <input type='number' id='precio_unitario' name='precio_unitario' step=".01" value="{{ old('precio_unitario', $product->precio_unitario ) }}"><br>
    @error('precio_unitario') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='categoria'>Categoria:</label>
    <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="{{ old('categoria', $product->categoria ) }}"><br>
    @error('categoria') <span class="error">{{ $message }}</span>@enderror<br><br>

    <input type="submit" value="Crear producto">

</form>
<style>
    .error {
        color: red;
    }
</style>
