<h1>Crea tu cuenta</h1>
    <form method="POST" action="{{ route('user.register') }}">
        @csrf <!-- Token csfr -->
        <label for='nick'>Nick:</label>
        <input type='text' id='nick' name='nick' value="{{ old('nick') }}"><br>
        @error('nick') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='email'>Email:</label>
        <input type='email' id='email' name='email' value="{{ old('email') }}"><br>
        @error('email') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='nombre'>Nombre:</label>
        <input type='text' id='nombre' name='nombre' value="{{ old('nombre') }}"><br>
        @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='apellidos'>Apellidos:</label>
        <input type='text' id='apellidos' name='apellidos' value="{{ old('apellidos') }}"><br>
        @error('apellidos') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='password'>Contraseña:</label>
        <input type='password' id='password' name='password'><br>
        @error('password') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='password_confirmation'>Confirmar contraseña:</label>
        <input type='password' id='password_confirmation' name='password_confirmation'><br>
        @error('password_confirmation') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='dni'>DNI:</label>
        <input type='text' id='dni' name='dni' value="{{ old('dni') }}"><br>
        @error('dni') <span class="error">{{ $message }}</span>@enderror<br><br>

        <label for='fecha_nacimiento'>Fecha de Nacimiento:</label>
        <input type='date' id='fecha_nacimiento' name='fecha_nacimiento' value="{{ old('fecha_nacimiento') }}"><br>
        @error('fecha_nacimiento') <span class="error">{{ $message }}</span>@enderror<br><br>
        
        <input type="submit" value="Crear cuenta">

    </form>

    <style>
        .error {
            color: red;
        }
    </style>