@if (session('status'))
<!-- Si se ha pasado algun mensaje, se muestra aqui -->
    <h1>{{ session('status') }}</h1>
@endif

<div class="user-settings">
    <!-- Botón para editar perfil pasando el id del usuario por url -->
    <a href="{{ route('user.edit-profile', Auth::id()) }}" class="edit-profile">Editar perfil</a>

    <!-- Cerrar sesión -->
    <a href="#" class="logout">Cerrar sesión</a>

    <!-- Confirmar cerrar sesion esocondido por js -->
    <a href="{{ route('user.logout') }}" class="confirm-logout show">Confirmar cerrar sessión</a>
</div>

<h1>
    Productos!
</h1>
<div class="flex">
    <!-- Formulario para mostrar productos -->
    <form method="GET" action="{{ route('user.show-products-default') }}">
        @csrf <!-- Token csfr -->
        <input type="submit" value="Mostrar productos">
    </form>

    <!-- Mostrar productos ordenados por precio -->
    <form method="GET" action="{{ route('user.show-products-sort-price') }}">
        @csrf <!-- Token csfr -->
        <input type="submit" value="Mostrar ordenado por precio">
    </form>

    <!-- Mostrar productos por categoria -->
    <form method="GET" action="{{ route('user.show-products-sort-category') }}">
        @csrf <!-- Token csfr -->
        <label for='categoria'>Categoria:</label>
        <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="{{ old('categoria') }}"><br>
        @error('categoria') <span class="error">{{ $message }}</span><br>@enderror

        <input type="submit" value="Mostrar ordenado por precio">
    </form>
</div>

<!-- Si se ha pasado la variable $productos -->
@if (isset($productos))
    @error('cantidad')<br><span class="error">{{ $message }}</span>@enderror
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            <th>Unidades</th>
            <th>Precio unitario</th>
            <th>Categoria</th>
            <th>Añadelo a tu cesta</th>
        </tr>

        <!-- foreach para recorrer cada registro del producto -->
        @foreach ($productos as $product)
            <tr>
                <td>
                    {{ $product->id }}
                </td>
                <td>
                    {{ $product->nombre }}
                </td>
                <td>
                    {{ $product->descripcion }}
                </td>
                <td>
                    {{ $product->unidades }}
                </td>
                <td>
                    {{ $product->precio_unitario }} €
                </td>
                <td>
                    {{ $product->categoria }}
                </td>
                <td>
                    <!-- Formulario para añadir al carrito -->
                    <form method="POST" action="{{ route('user.add-to-cart', $product) }}">
                        @csrf
                        <label for='cantidad'>Cantidad:</label>
                        <input type='number' id='cantidad' name='cantidad'>

                        <input type="submit" value="Add to Cart">
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endif

<h1>
    Categorias!
</h1>
<div class="flex">
    <!-- Formulario para mostrar categorias -->
    <form method="GET" action="{{ route('user.show-category') }}">
        @csrf <!-- Token csfr -->
        <input type="submit" value="Mostrar productos">
    </form>
</div>

<!-- Si se ha pasado la variable $categorias -->
@if (isset($categorias))
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripcion</th>
        </tr>

        <!-- foreach para recorrer cada registro de una categoria -->
        @foreach ($categorias as $categoria)
            <tr>
                <td>
                    {{ $categoria->id }}
                </td>
                <td>
                    {{ $categoria->nombre }}
                </td>
                <td>
                    {{ $categoria->descripcion }}
                </td>
            </tr>
        @endforeach
    </table>
@endif

<h1>
    Tu carrito!
</h1>
<div class="flex">
    <!-- Formulario para mostrar el carrito -->
    <form method="GET" action="{{ route('user.show-carrito') }}">
        @csrf <!-- Token csfr -->
        <input type="submit" value="Mostrar carrito">
    </form>
</div>

<!-- Si se ha pasado la variable $carritos -->
@if (isset($carritos))
    <table>
        <tr>
            <th>Id</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio producto</th>
            <th>Total</th>
            <th>Eliminar</th>
        </tr>

        <!-- foreach para recorrer cada registro del carrito -->
        @foreach ($carritos as $carro)
            <tr>
                <td>
                    {{ $carro->id }}
                </td>
                <td>
                    {{ $carro->producto }}
                </td>
                <td>
                    {{ $carro->cantidad }}
                </td>
                <td>
                    {{ $carro->precio_producto }} €
                 </td>
                <td>
                    {{ $carro->total }} €
                </td>
                <td>
                    <!-- Eliminar el registro del carrito -->
                    <form method="POST" action="{{ route('user.destroy-carrito', $carro) }}">
                        @csrf @method('DELETE')
                        <input type="submit" value="Eliminar">
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endif

<style>
    .user-settings {
        position: absolute;
        right: 10vh;
        top: 5vh;
        display: flex;
        flex-flow: column;
        gap: 30px;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }

    .error {
        color: red;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }
    
    .show {
        display: none;
    }
</style>

<script>
/** 
 * Script para mostrar el botón de confirmar cerrar sesión
 * cuando se pulsa cerrar sesión
 */
    document.addEventListener('DOMContentLoaded', function() {
            let logout = document.querySelector('.logout');

            if(logout) {
                logout.addEventListener('click', function(event) {
                    event.preventDefault();
                    let confirm = document.querySelector('.confirm-logout');

                    if (confirm.classList.contains('show')) {
                        confirm.classList.remove('show');
                    } else {
                        confirm.classList.add('show');
                    }
                });
            }
        });
</script>