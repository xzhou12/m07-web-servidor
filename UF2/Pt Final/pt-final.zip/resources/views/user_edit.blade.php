<form method="POST" action="{{ route('admin.update-user', $user) }}">
    @csrf @method('PUT')
    <!-- Token csfr -->
    <label for='nick'>Nick:</label>
    <input type='text' id='nick' name='nick' value="{{ old('nick', $user->nick) }}"><br>
    @error('nick') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='email'>Email:</label>
    <input type='email' id='email' name='email' value="{{ old('email', $user->email) }}"><br>
    @error('email') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='nombre'>Nombre:</label>
    <input type='text' id='nombre' name='nombre' value="{{ old('nombre', $user->nombre) }}"><br>
    @error('nombre') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='apellidos'>Apellidos:</label>
    <input type='text' id='apellidos' name='apellidos' value="{{ old('apellidos', $user->apellidos) }}"><br>
    @error('apellidos') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='dni'>DNI:</label>
    <input type='text' id='dni' name='dni' value="{{ old('dni', $user->dni) }}"><br>
    @error('dni') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='fecha_nacimiento'>Fecha de Nacimiento:</label>
    <input type='date' id='fecha_nacimiento' name='fecha_nacimiento' value="{{ old('fecha_nacimiento', $user->fecha_nacimiento) }}"><br>
    @error('fecha_nacimiento') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='rol'>Rol:</label>
    <select id='rol' name='rol'>
        <option value="user" {{ $user->rol =='user' ? 'selected' : '' }}>Usuario</option>
        <option value="admin" {{ $user->rol == 'admin' ? 'selected' : '' }}>Administrador</option>
    </select><br>
    @error('rol') <span class="error">{{ $message }}</span>@enderror<br><br>

    <input type="submit" value="Guardar datos">

</form>
