<form method="POST" action="{{ route('user.update-user', $user) }}">
    @csrf @method('PUT')
    <!-- Token csfr -->
    <label for='nick'>Nick:</label>
    <input type='text' id='nick' name='nick' value="{{ old('nick', $user->nick) }}"><br>
    @error('nick') <span class="error">{{ $message }}</span>@enderror<br><br>

    <label for='email'>Email:</label>
    <input type='email' id='email' name='email' value="{{ old('email', $user->email) }}"><br>
    @error('email') <span class="error">{{ $message }}</span>@enderror<br><br>

    <input type="submit" value="Guardar datos">

</form>
<style>
    .error {
        color: red;
    }
</style>