@if (session('status'))
    <h1>{{ session('status') }}</h1>
@endif

<div class="buttons">
    <a href="{{ route('login') }}">Login</a>
    <a href="{{ route('register') }}">Register</a>
</div>


<style>
    .buttons {
        display: flex;
        flex-flow: row;
        gap: 50px;
        justify-content: center;
        top: 30vh;
    }
</style>