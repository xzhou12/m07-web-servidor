<?php
use Illuminate\Support\Facades\Route;

use App\Http\Middleware\Authenticate;

use App\Http\Controllers\UserController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\CarritoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Home (sin loguear)
Route::view('/', 'welcome')
    ->name('home');

// Pagina login
Route::view('/login', 'login')
    ->name('login');

// Pagina register
Route::view('/register', 'register')
    ->name('register');

// Procesar login
Route::post('/login/go', [UserController::class, 'login'])
    ->name('user.login');

// Crear cuenta
Route::post('/register/create', [UserController::class, 'register'])
    ->name('user.register');

// Middleware usurario creado
Route::middleware([Authenticate::class])->group(function () {
    Route::get('logout', [UserController::class, 'logout'])
        ->name('user.logout');

    // Middleware usuario creado + user
    Route::middleware(['checkRole:user'])->group(function () {
        Route::view('/home', 'user')
            ->name('user.home');

        // USUARIO
        Route::get('/user/{user}/profile', [UserController::class, 'profile'])
            ->name('user.edit-profile');

        Route::put('/user/{user}/updated', [UserController::class, 'userUpdate'])
            ->name('user.update-user');

        // PRODUCTOS
        Route::get('/products/show/default', [ProductoController::class, 'showDefault'])
            ->name('user.show-products-default');

        Route::get('/products/show/price', [ProductoController::class, 'showSortPrice'])
            ->name('user.show-products-sort-price');

        Route::get('/products/show/category', [ProductoController::class, 'showSortCategory'])
            ->name('user.show-products-sort-category');

        // CATEGORIAS
        Route::get('/category/show/default', [CategoriaController::class, 'showUser'])
            ->name('user.show-category');

        // CARRITO
        Route::post('/cart/{producto}/add', [CarritoController::class, 'store'])
            ->name('user.add-to-cart');

        Route::get('/cart/show', [CarritoController::class, 'show'])
            ->name('user.show-carrito');

        Route::delete('/cart/{carrito}/destroy', [CarritoController::class, 'destroy'])
            ->name('user.destroy-carrito');
    });

    // Middleware usuario creado + admin
    Route::middleware(['checkRole:admin'])->group(function () {
        Route::view('/admin', 'admin')
            ->name('admin.home');

        // USER
        Route::post('/user/add', [UserController::class, 'store'])
            ->name('admin.add-user');

        Route::get('/user/show', [UserController::class, 'show'])
            ->name('admin.get-user');

        Route::get('/user/{user}/edit', [UserController::class, 'edit'])
            ->name('admin.edit-user');

        Route::put('/user/{user}/update', [UserController::class, 'update'])
            ->name('admin.update-user');

        Route::delete('/user/{user}/destroy', [UserController::class, 'destroy'])
            ->name('admin.destroy-user');


        // CATEGORIA
        Route::post('/category/add', [CategoriaController::class, 'store'])
            ->name('admin.add-category');

        Route::get('/category/show', [CategoriaController::class, 'show'])
            ->name('admin.get-category');

        Route::get('/category/{categoria}/edit', [CategoriaController::class, 'edit'])
            ->name('admin.edit-category');

        Route::put('/category/{categoria}/update', [CategoriaController::class, 'update'])
            ->name('admin.update-category');

        Route::delete('/category/{categoria}/destroy', [CategoriaController::class, 'destroy'])
            ->name('admin.destroy-category');

        // PRODUCTOS
        Route::post('/product/add', [ProductoController::class, 'store'])
            ->name('admin.add-product');

        Route::get('/product/show', [ProductoController::class, 'show'])
            ->name('admin.get-products');

        Route::get('/product/{producto}/edit', [ProductoController::class, 'edit'])
            ->name('admin.edit-product');

        Route::put('/product/{producto}/update', [ProductoController::class, 'update'])
            ->name('admin.update-product');

        Route::delete('/product/{producto}/destroy', [ProductoController::class, 'destroy'])
            ->name('admin.destroy-product');

    });
});


