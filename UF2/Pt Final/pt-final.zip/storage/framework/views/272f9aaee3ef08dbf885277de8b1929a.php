<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>

<div class="buttons">
    <a href="<?php echo e(route('login')); ?>">Login</a>
    <a href="<?php echo e(route('register')); ?>">Register</a>
</div>


<style>
    .buttons {
        display: flex;
        flex-flow: row;
        gap: 50px;
        justify-content: center;
        top: 30vh;
    }
</style><?php /**PATH C:\xampp\htdocs\act3\resources\views/welcome.blade.php ENDPATH**/ ?>