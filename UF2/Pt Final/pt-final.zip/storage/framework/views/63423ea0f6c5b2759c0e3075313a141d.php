<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>


<div class="user-settings">
    <a href="#" class="logout">Cerrar sesión</a>

    <a href="<?php echo e(route('user.logout')); ?>" class="confirm-logout show">Confirmar cerrar sessión</a>
</div>

<h1>Usuarios!</h1>
<div class="flex usuarios">
    <div class="row">
        <h2>Crea un usuario:</h2>
        <form method="POST" action="<?php echo e(route('admin.add-user')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <label for='nick'>Nick:</label>
            <input type='text' id='nick' name='nick' value="<?php echo e(old('nick')); ?>"><br>
            <?php $__errorArgs = ['nick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='email'>Email:</label>
            <input type='email' id='email' name='email' value="<?php echo e(old('email')); ?>"><br>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="<?php echo e(old('nombre')); ?>"><br>
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='apellidos'>Apellidos:</label>
            <input type='text' id='apellidos' name='apellidos' value="<?php echo e(old('apellidos')); ?>"><br>
            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='password'>Contraseña:</label>
            <input type='password' id='password' name='password'><br>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='password_confirmation'>Confirmar contraseña:</label>
            <input type='password' id='password_confirmation' name='password_confirmation'><br>
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='dni'>DNI:</label>
            <input type='text' id='dni' name='dni' value="<?php echo e(old('dni')); ?>"><br>
            <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='fecha_nacimiento'>Fecha de Nacimiento:</label>
            <input type='date' id='fecha_nacimiento' name='fecha_nacimiento' value="<?php echo e(old('fecha_nacimiento')); ?>"><br>
            <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='rol'>Rol:</label>
            <select id='rol' name='rol'>
                <option value='user' <?php echo e(old('rol') === 'user' ? 'selected' : ''); ?>>Usuario</option>
                <option value='admin' <?php echo e(old('rol') === 'admin' ? 'selected' : ''); ?>>Administrador</option>
            </select><br>
            <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <input type="submit" value="Crear cuenta">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos los usuarios</h2>
        <form method="GET" action="<?php echo e(route('admin.get-user')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <input type="submit" value="Mostrar usuarios">
        </form>
        <br>
        <br>

        <?php if(isset($users)): ?>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nick</th>
                    <th>Email</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>DNI</th>
                    <th>Fecha nacimiento</th>
                    <th>Rol</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de usuario -->
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($user->id); ?>

                    </td>
                    <td>
                        <?php echo e($user->nick); ?>

                    </td>
                    <td>
                        <?php echo e($user->email); ?>

                    </td>
                    <td>
                        <?php echo e($user->nombre); ?>

                    </td>
                    <td>
                        <?php echo e($user->apellidos); ?>

                    </td>
                    <td>
                        <?php echo e($user->dni); ?>

                    </td>
                    <td>
                        <?php echo e($user->fecha_nacimiento); ?>

                    </td>
                    <td>
                        <?php echo e($user->rol); ?>

                    </td>

                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-user -->
                        <a href="<?php echo e(route('admin.edit-user', $user)); ?>">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a  admin.destroy-user-->
                        <form method="POST" action="<?php echo e(route('admin.destroy-user', $user)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
</div>

<br>
<br>
<h1>Categorias!</h1>
<div class="flex categoria">
    <div class="row">
        <h2>Crea una categoria:</h2>
        <form method="POST" action="<?php echo e(route('admin.add-category')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="<?php echo e(old('nombre')); ?>"><br>
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='descripcion'>Descripción:</label>
            <input type='text' id='descripcion' name='descripcion' value="<?php echo e(old('descripcion')); ?>"><br>
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <input type="submit" value="Crear categoria">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos las categorias</h2>
        <form method="GET" action="<?php echo e(route('admin.get-category')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <input type="submit" value="Mostrar categorias">
        </form>
        <br>
        <br>

        <?php if(isset($categories)): ?>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de una categoria -->
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($category->id); ?>

                    </td>
                    <td>
                        <?php echo e($category->nombre); ?>

                    </td>
                    <td>
                        <?php echo e($category->descripcion); ?>

                    </td>
                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-category -->
                        <a href="<?php echo e(route('admin.edit-category', $category)); ?>">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a admin.destroy-cateogry -->
                        <form method="POST" action="<?php echo e(route('admin.destroy-category', $category)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
</div>

<br>
<br>
<h1>Productos!</h1>
<div class="flex productos">
    <div class="row">
        <h2>Crea un producto:</h2>
        <form method="POST" action="<?php echo e(route('admin.add-product')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <label for='nombre'>Nombre:</label>
            <input type='text' id='nombre' name='nombre' value="<?php echo e(old('nombre')); ?>"><br>
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='descripcion'>Descripción:</label>
            <input type='text' id='descripcion' name='descripcion' value="<?php echo e(old('descripcion')); ?>"><br>
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='unidades'>Unidades:</label>
            <input type='number' id='unidades' name='unidades' value="<?php echo e(old('unidades')); ?>"><br>
            <?php $__errorArgs = ['unidades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='precio_unitario'>Precio unitario:</label>
            <input type='number' id='precio_unitario' name='precio_unitario' step=".01" value="<?php echo e(old('precio_unitario')); ?>"><br>
            <?php $__errorArgs = ['precio_unitario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <label for='categoria'>Categoria:</label>
            <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="<?php echo e(old('categoria')); ?>"><br>
            <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

            <input type="submit" value="Crear producto">

        </form>
    </div>
    <div class="row">
        <h2>Muestra todos los productos</h2>
        <form method="GET" action="<?php echo e(route('admin.get-products')); ?>">
            <?php echo csrf_field(); ?> <!-- Token csfr -->
            <input type="submit" value="Mostrar productos">
        </form>

        <?php if(isset($productos)): ?>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Unidades</th>
                    <th>Precio unitario</th>
                    <th>Categoria</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>

                <!-- foreach para recorrer cada registro de una categoria -->
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($product->id); ?>

                    </td>
                    <td>
                        <?php echo e($product->nombre); ?>

                    </td>
                    <td>
                        <?php echo e($product->descripcion); ?>

                    </td>
                    <td>
                        <?php echo e($product->unidades); ?>

                    </td>
                    <td>
                        <?php echo e($product->precio_unitario); ?> €
                    </td>
                    <td>
                        <?php echo e($product->categoria); ?>

                    </td>
                    <td>
                        <!-- Si se da a editar, se redirige a la ruta admin.edit-product -->
                        <a href="<?php echo e(route('admin.edit-product', $product)); ?>">
                            Editar
                        </a>
                    </td>
                    <td>
                        <!-- Si se quiere eliminar, se redirige a admin.destroy-product -->
                        <form method="POST" action="<?php echo e(route('admin.destroy-product', $product)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>
</div>

<style>
    .log-out {
        position: absolute;
        right: 10vh;
        top: 5vh;
    }

    .error {
        color: red;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 10vh;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }

    .user-settings {
        position: absolute;
        right: 10vh;
        top: 5vh;
        display: flex;
        flex-flow: column;
        gap: 30px;
    }

    .show {
        display: none;
    }
</style>
<script>
    document.addEventListener('DOMContentLoaded', function() {
            let logout = document.querySelector('.logout');

            if(logout) {
                logout.addEventListener('click', function(event) {
                    event.preventDefault();
                    let confirm = document.querySelector('.confirm-logout');

                    if (confirm.classList.contains('show')) {
                        confirm.classList.remove('show');
                    } else {
                        confirm.classList.add('show');
                    }
                });
            }
        });
</script><?php /**PATH C:\xampp\htdocs\act3\resources\views/admin.blade.php ENDPATH**/ ?>