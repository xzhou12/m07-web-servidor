<form method="POST" action="<?php echo e(route('admin.update-user', $user)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <!-- Token csfr -->
    <label for='nick'>Nick:</label>
    <input type='text' id='nick' name='nick' value="<?php echo e(old('nick', $user->nick)); ?>"><br>
    <?php $__errorArgs = ['nick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='email'>Email:</label>
    <input type='email' id='email' name='email' value="<?php echo e(old('email', $user->email)); ?>"><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='nombre'>Nombre:</label>
    <input type='text' id='nombre' name='nombre' value="<?php echo e(old('nombre', $user->nombre)); ?>"><br>
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='apellidos'>Apellidos:</label>
    <input type='text' id='apellidos' name='apellidos' value="<?php echo e(old('apellidos', $user->apellidos)); ?>"><br>
    <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='dni'>DNI:</label>
    <input type='text' id='dni' name='dni' value="<?php echo e(old('dni', $user->dni)); ?>"><br>
    <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='fecha_nacimiento'>Fecha de Nacimiento:</label>
    <input type='date' id='fecha_nacimiento' name='fecha_nacimiento' value="<?php echo e(old('fecha_nacimiento', $user->fecha_nacimiento)); ?>"><br>
    <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='rol'>Rol:</label>
    <select id='rol' name='rol'>
        <option value="user" <?php echo e($user->rol =='user' ? 'selected' : ''); ?>>Usuario</option>
        <option value="admin" <?php echo e($user->rol == 'admin' ? 'selected' : ''); ?>>Administrador</option>
    </select><br>
    <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit" value="Guardar datos">

</form>
<?php /**PATH C:\xampp\htdocs\act3\resources\views/user_edit.blade.php ENDPATH**/ ?>