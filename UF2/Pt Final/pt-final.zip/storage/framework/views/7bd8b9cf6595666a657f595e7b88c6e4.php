<?php if(session('status')): ?>
<!-- Si se ha pasado algun mensaje, se muestra aqui -->
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>

<div class="user-settings">
    <!-- Botón para editar perfil pasando el id del usuario por url -->
    <a href="<?php echo e(route('user.edit-profile', Auth::id())); ?>" class="edit-profile">Editar perfil</a>

    <!-- Cerrar sesión -->
    <a href="#" class="logout">Cerrar sesión</a>

    <!-- Confirmar cerrar sesion esocondido por js -->
    <a href="<?php echo e(route('user.logout')); ?>" class="confirm-logout show">Confirmar cerrar sessión</a>
</div>

<h1>
    Productos!
</h1>
<div class="flex">
    <!-- Formulario para mostrar productos -->
    <form method="GET" action="<?php echo e(route('user.show-products-default')); ?>">
        <?php echo csrf_field(); ?> <!-- Token csfr -->
        <input type="submit" value="Mostrar productos">
    </form>

    <!-- Mostrar productos ordenados por precio -->
    <form method="GET" action="<?php echo e(route('user.show-products-sort-price')); ?>">
        <?php echo csrf_field(); ?> <!-- Token csfr -->
        <input type="submit" value="Mostrar ordenado por precio">
    </form>

    <!-- Mostrar productos por categoria -->
    <form method="GET" action="<?php echo e(route('user.show-products-sort-category')); ?>">
        <?php echo csrf_field(); ?> <!-- Token csfr -->
        <label for='categoria'>Categoria:</label>
        <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="<?php echo e(old('categoria')); ?>"><br>
        <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><br><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="submit" value="Mostrar ordenado por precio">
    </form>
</div>

<!-- Si se ha pasado la variable $productos -->
<?php if(isset($productos)): ?>
    <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><br><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripcion</th>
            <th>Unidades</th>
            <th>Precio unitario</th>
            <th>Categoria</th>
            <th>Añadelo a tu cesta</th>
        </tr>

        <!-- foreach para recorrer cada registro del producto -->
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($product->id); ?>

                </td>
                <td>
                    <?php echo e($product->nombre); ?>

                </td>
                <td>
                    <?php echo e($product->descripcion); ?>

                </td>
                <td>
                    <?php echo e($product->unidades); ?>

                </td>
                <td>
                    <?php echo e($product->precio_unitario); ?> €
                </td>
                <td>
                    <?php echo e($product->categoria); ?>

                </td>
                <td>
                    <!-- Formulario para añadir al carrito -->
                    <form method="POST" action="<?php echo e(route('user.add-to-cart', $product)); ?>">
                        <?php echo csrf_field(); ?>
                        <label for='cantidad'>Cantidad:</label>
                        <input type='number' id='cantidad' name='cantidad'>

                        <input type="submit" value="Add to Cart">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>

<h1>
    Categorias!
</h1>
<div class="flex">
    <!-- Formulario para mostrar categorias -->
    <form method="GET" action="<?php echo e(route('user.show-category')); ?>">
        <?php echo csrf_field(); ?> <!-- Token csfr -->
        <input type="submit" value="Mostrar productos">
    </form>
</div>

<!-- Si se ha pasado la variable $categorias -->
<?php if(isset($categorias)): ?>
    <table>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Descripcion</th>
        </tr>

        <!-- foreach para recorrer cada registro de una categoria -->
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($categoria->id); ?>

                </td>
                <td>
                    <?php echo e($categoria->nombre); ?>

                </td>
                <td>
                    <?php echo e($categoria->descripcion); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>

<h1>
    Tu carrito!
</h1>
<div class="flex">
    <!-- Formulario para mostrar el carrito -->
    <form method="GET" action="<?php echo e(route('user.show-carrito')); ?>">
        <?php echo csrf_field(); ?> <!-- Token csfr -->
        <input type="submit" value="Mostrar carrito">
    </form>
</div>

<!-- Si se ha pasado la variable $carritos -->
<?php if(isset($carritos)): ?>
    <table>
        <tr>
            <th>Id</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio producto</th>
            <th>Total</th>
            <th>Eliminar</th>
        </tr>

        <!-- foreach para recorrer cada registro del carrito -->
        <?php $__currentLoopData = $carritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($carro->id); ?>

                </td>
                <td>
                    <?php echo e($carro->producto); ?>

                </td>
                <td>
                    <?php echo e($carro->cantidad); ?>

                </td>
                <td>
                    <?php echo e($carro->precio_producto); ?> €
                 </td>
                <td>
                    <?php echo e($carro->total); ?> €
                </td>
                <td>
                    <!-- Eliminar el registro del carrito -->
                    <form method="POST" action="<?php echo e(route('user.destroy-carrito', $carro)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <input type="submit" value="Eliminar">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>

<style>
    .user-settings {
        position: absolute;
        right: 10vh;
        top: 5vh;
        display: flex;
        flex-flow: column;
        gap: 30px;
    }

    .flex {
        display: flex;
        flex-flow: row wrap;
        gap: 50px;
    }

    .error {
        color: red;
    }

    table {
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid black;
        padding: 5px;
        text-align: center;
    }
    
    .show {
        display: none;
    }
</style>

<script>
/** 
 * Script para mostrar el botón de confirmar cerrar sesión
 * cuando se pulsa cerrar sesión
 */
    document.addEventListener('DOMContentLoaded', function() {
            let logout = document.querySelector('.logout');

            if(logout) {
                logout.addEventListener('click', function(event) {
                    event.preventDefault();
                    let confirm = document.querySelector('.confirm-logout');

                    if (confirm.classList.contains('show')) {
                        confirm.classList.remove('show');
                    } else {
                        confirm.classList.add('show');
                    }
                });
            }
        });
</script><?php /**PATH C:\xampp\htdocs\pt-final\resources\views/user.blade.php ENDPATH**/ ?>