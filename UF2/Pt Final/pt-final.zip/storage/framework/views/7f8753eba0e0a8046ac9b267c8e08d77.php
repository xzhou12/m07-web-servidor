<?php if(session('status')): ?>
<!-- Si se ha pasado algun mensaje, se muestra aqui -->
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>


<h1>Accede a tu cuenta</h1>
<form method="POST" action="<?php echo e(route('user.login')); ?>">
    <?php echo csrf_field(); ?> <!-- Token csfr -->
    <label for="dni">DNI:</label>
    <input type="text" name="dni" id="dni" value="<?php echo e(old('dni')); ?>"><br>
    <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for="password">Contraseña:</label>
    <input type="password" name="password" id="password"><br>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit" value="Acceder">

</form>

<style>
    .error {
        color: red;
    }
</style>
<?php /**PATH C:\xampp\htdocs\pt-final\resources\views/login.blade.php ENDPATH**/ ?>