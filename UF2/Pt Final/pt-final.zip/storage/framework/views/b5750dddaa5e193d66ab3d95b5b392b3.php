<?php if(session('status')): ?>
    <h1><?php echo e(session('status')); ?></h1>
<?php endif; ?>

<a href="<?php echo e(route('login')); ?>">Login</a>
<a href="<?php echo e(route('register')); ?>">Register</a><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/act3/resources/views/welcome.blade.php ENDPATH**/ ?>