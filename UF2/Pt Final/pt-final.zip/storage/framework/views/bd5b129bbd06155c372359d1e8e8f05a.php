<form method="POST" action="<?php echo e(route('admin.update-product', $product)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <label for='nombre'>Nombre:</label>
    <input type='text' id='nombre' name='nombre' value="<?php echo e(old('nombre', $product->nombre )); ?>"><br>
    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='descripcion'>Descripción:</label>
    <input type='text' id='descripcion' name='descripcion' value="<?php echo e(old('descripcion', $product->descripcion )); ?>"><br>
    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='unidades'>Unidades:</label>
    <input type='number' id='unidades' name='unidades' value="<?php echo e(old('unidades', $product->unidades )); ?>"><br>
    <?php $__errorArgs = ['unidades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='precio_unitario'>Precio unitario:</label>
    <input type='number' id='precio_unitario' name='precio_unitario' step=".01" value="<?php echo e(old('precio_unitario', $product->precio_unitario )); ?>"><br>
    <?php $__errorArgs = ['precio_unitario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='categoria'>Categoria:</label>
    <input type='number' id='categoria' name='categoria' placeholder="ID de categoria" value="<?php echo e(old('categoria', $product->categoria )); ?>"><br>
    <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit" value="Crear producto">

</form>
<?php /**PATH C:\xampp\htdocs\act3\resources\views/product_edit.blade.php ENDPATH**/ ?>