<form method="POST" action="<?php echo e(route('user.update-user', $user)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <!-- Token csfr -->
    <label for='nick'>Nick:</label>
    <input type='text' id='nick' name='nick' value="<?php echo e(old('nick', $user->nick)); ?>"><br>
    <?php $__errorArgs = ['nick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <label for='email'>Email:</label>
    <input type='email' id='email' name='email' value="<?php echo e(old('email', $user->email)); ?>"><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>

    <input type="submit" value="Guardar datos">

</form>
<style>
    .error {
        color: red;
    }
</style><?php /**PATH C:\xampp\htdocs\pt-final\resources\views/user_profile.blade.php ENDPATH**/ ?>