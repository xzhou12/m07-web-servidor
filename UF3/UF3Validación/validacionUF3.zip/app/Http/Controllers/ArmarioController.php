<?php

namespace App\Http\Controllers;

use App\Models\armario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ArmarioController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda una prenda de ropa en el armario
     */
    public function store(Request $request)
    {
        try {

            // Valida los datos
            $validatedData = $request->validate([
                'nombre' => 'required',
                'talla' => 'required',
                'color' => 'required',
                'user_id' => ['required', 'exists:users,id'],
            ]);

            // Y los introduce mediante una transaccion
            DB::transaction(function () use ($validatedData) {
                armario::create($validatedData);
            });

            // Mensaje de confirmación
            return response()->json(['message' => 'Armario creado'], 201);

        } catch (\Exception $e) {
            // Mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error en el servidor' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra todo el armario
     */
    public function show()
    {
        try {

            // Selecciona todo el armario
            $armario = armario::all();

            // Y lo devuelve
            return response()->json(['message' => $armario], 201);

        } catch (\Exception $e) {
            // Mensaje de error
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * @param $user
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra todo el armario de x usuario
     */
    public function showUser($user)
    {
        try {

            // Hace la sentencia para seleccionar todas las prendas de x usuario
            $armario = armario::where('user_id', $user)->get();

            // Y las devuelve
            return response()->json(['message' => $armario], 201);

        } catch (\Exception $e) {
            // Mensaje de error
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @param armario $armario
     * @return \Illuminate\Http\JsonResponse
     *
     * Actualiza una prenda de ropa existente en el armario
     */
    public function update(Request $request, armario $armario)
    {
        try {

            // Comprueba si el id que se ha pasado por parametro existe
            if (!is_null($armario)) {

                // Valida los datos
                $validatedData = $request->validate([
                    'nombre' => 'required',
                    'talla' => 'required',
                    'color' => 'required',
                    'user_id' => ['required', 'exists:users,id'],
                ]);

                // Hace el update mediante una transacción
                DB::transaction(function () use ($validatedData, $armario) {
                    $armario->update($validatedData);
                });

                // Mensaje de confirmación
                return response()->json(['message' => 'Armario actualizado'], 201);

            } else {
                // Si no ha encontrado el armario
                return response()->json(['message' => 'Armario no encontrado'], 404);
            }
        } catch (\Exception $e) {
            // Mensaje de otro tipo de error
            return response()->json(['message' => 'Ha ocurrido un error en el servidor' . $e->getMessage()], 500);
        }
    }


    /**
     * @param armario $armario
     * @return \Illuminate\Http\JsonResponse
     *
     * Elimina la prenda del armario
     */
    public function destroy(armario $armario)
    {
        try {

            // Comprueba si es valido
            if (!is_null($armario)) {
                // Elimina la prenda
                DB::transaction(function () use ($armario) {
                    $armario->delete();
                });

                // Y muestra mensaje de confirmación
                return response()->json(['message' => 'Armario eliminado'], 201);
            } else {
                return response()->json(['message' => 'Armario no encontrado'], 404);
            }

        } catch (\Exception $e) {
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }
}
