<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\ArmarioController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::post('armario', [ArmarioController::class, 'store']);

Route::delete('armario/{armario}', [ArmarioController::class, 'destroy']);

Route::get('armario', [ArmarioController::class, 'show']);

Route::get('armario/{user_id}', [ArmarioController::class, 'showUser']);

Route::put('armario/{armario}', [ArmarioController::class, 'update']);
